
Name : R Amshu Naik
Roll No: B20CS046

# Introduction to Financial Engineering
##  Project 1 - Technical Analysis

### About Dataset:

For this Project Nasdaq Stock data is Choosen.  The columns include the opening price (Open), highest price (High), lowest price (Low), closing price (Close), adjusted closing price (Adj Close), and trading volume (Volume) for each respective date. I had set the index of the data to be Date for easy analysis and plotting.  The data provides info about the market performance of the NASDAQ index,the price movements and trading activity over the specified time period.

### Steps to run the ass1.ipynb file:

1. Download the folder "financial" or copy paste in desktop.
2. Then open Vscode, install all the python libraries mentioned on top.
3. Run all the cells.

### Technical Indicators

The Techical Indicators to analyse the trend, oscillation and volatility are :

1. SMA (Simple Moving Average)

-> Moving averages helps to identify trends
-> To get the SMA I calculated rolling mean of a specified window size of  column "Close".

2. EMA (Exponential Moving Average)

->It also help in identifying trends.
-> It is used for evaluating the bullish and bearish trends  over a certain span of duration.
-> EMA put more empasis on recent data than SMA.

3. RSI (Relative Strength Index)

-> A momentum oscillator that measures the speed and change of price movements 
-> RSI generates a value from 0 to 100 that reflects the strength or weakness of the asset’s price momentum.
-> If RSI value less than 30 means its oversold , generate buy signal, and if more than 70 then its overbought , generate sell signal.

4. MACD (Moving Average Convergence-Divergence)

-> The indicator is used to define momentum and its directional resilience.
-> If EWA12 is above EWA26 then MACD is a positive value and if EWA12 value below EWA26 then MACD is a negative value.
-> The MACD is calculated by deducting the short-term EMA from the long-term EMA (26 periods) and (12 periods).

5. Bollinger Bands

-> Bollinger Bands  a versatile technical analysis tool that can be used to identify trends, volatility, and  breakouts.
-> The three components are the middle, upper, and lower bands. The upper and lower bands are based on standard deviations, and average in the middle band which is EWA of window size 25.

6. NVI (Negative volume Index)

-> It provide insight into the effect of volume on the price trend of a security.
-> In NVI the values used in the indicator in the current period will be used in future values for the previous period.
-> The cumulative Negative Volume Index (NVI) is calculated by adding the product of the percentage change in the closing price from the previous day and the previous day's NVI to the existing NVI value.

### Correlation Analysis

For finding the correlation the 4 indicators choosen are Moving average, MACD, Bollinger_Bands and NVI as all these indicators provide different info like MA about trends, MACD provide Oscillation and momentum of price, bollinger and about the volatility in price nd NVI about the market liquidity and effect due to volume . For determing the corrrelation between the indicators , used corr() function. 

### Combined Indicator

-> For finding the combined Indicator the 4 indicators choosen are Moving average, MACD, Bollinger_Bands and NVI as all these indicators provide different info like MA about trends, MACD provide Oscillation and momentum of price, bollinger and about the volatility in price nd NVI about the market liquidity and effect due to volume . 
-> Weights to the indicators were assigned on the basis of the correlation value the indicators have. The one with more overall correlation value has more weight.
-> find the combined indicator using the weighted average formula

### Methodology for Predictions

Steps for Methodology includes :

-> Used Exponential Moving Average (EMA) for smoothing the combined indicator (Combine_Indicator), and then creating signals and predictions based on certain conditions.
-> Signal generation as buy if  Combine_Indicator is greater than the EMA (Ind), assign a value of 1; otherwise, assign 0. 
( 1 to buy and 0 to sell)
-> Then Replacing 1 value with "L" and 0 with "S".
-> Then calculate the difference between consecutive Signal_final values to identify entry and exit points.
-> Plot the graph.

### Predict Accuracy

-> To predict accuracy generate the signal for all the 4 indicator used and determine the accuracy of each indicator with the final predicted signal of the combined indicator using the accuracy_score function.
-> The accuracy coming is about 82.25%.

### Result and Conclusion

1. The overall accuracy of the combined indicator is 82.17%.
2. RSI giving negative correlation must not be choosen.
3. Choose indicators providing different info about the data.
4. Window size and period must be wisely chosen as it affect the result.
5. RSI and MSID much not be chosen together to form combined indicator as they provide same info.
